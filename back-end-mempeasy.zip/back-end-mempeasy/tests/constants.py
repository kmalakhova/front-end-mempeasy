TEST_STR = "the pig likes to dig"
ONLY_LETTERS = ["the", "rat", "is", "fat"]
WSYMBOL = ["can", "you", "be", "ready", "at", "five", "?"]
WNUMBER = ["3",":","05","PM"]
WSYMBOL_WNUMBER = ["it", "is", "Aug", "10", "already", "!"]
SYMBOL = ["!","$",":",";","?","-"]
